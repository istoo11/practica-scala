error id: file:///C:/Users/AlumnoM_AI/torneo-twenty-one/src/main/scala/Main.scala:scala/collection/immutable/List#length().
file:///C:/Users/AlumnoM_AI/torneo-twenty-one/src/main/scala/Main.scala
empty definition using pc, found symbol in pc: scala/collection/immutable/List#length().
empty definition using semanticdb
empty definition using fallback
non-local guesses:
	 -jugadores/length.
	 -jugadores/length#
	 -jugadores/length().
	 -scala/Predef.jugadores.length.
	 -scala/Predef.jugadores.length#
	 -scala/Predef.jugadores.length().
offset: 652
uri: file:///C:/Users/AlumnoM_AI/torneo-twenty-one/src/main/scala/Main.scala
text:
```scala
object Main extends App {

    def bust(puntuacion: Int): Boolean = puntuacion > 21
    def estadoMano(puntuacion: Int): String = {
        if(puntuacion > 21){
            "BUST"
        }else{
            "VALIDA"
        }
    }
    def mejorMano(handA: Int, handB: Int): Int ={
        if( handA > 21 && handB > 21){
            0
        } else if( handA > 21){
            handB
        } else if ( handB > 21){
            handA
        }else{
            handA.max(handB)
        }
    }

    val jugadores = List("Alex","Chen","Marta","Sindhu","Luis")
    val puntuaciones = Array(18,24,21,20,26)

    var i = 0 
    while (i< jugadores.length@@){
        println(jugadores(i) + " -> " + puntuaciones(i) + " -> " + estadoMano(puntuaciones(i)))
        i = i + 1
    }

    println("Numero total de jugadores: " + +)

}

```


#### Short summary: 

empty definition using pc, found symbol in pc: scala/collection/immutable/List#length().